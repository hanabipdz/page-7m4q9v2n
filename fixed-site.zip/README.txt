独立射击游戏档案：本地优化版

内容：
- index.html：修复详情页复核记录崩溃、封面属性转义与图片统计。
- assets/images/：由原页面内嵌 WebP 图像拆出的本地资源；相同图片按哈希去重。

离线浏览时，请保留 index.html 与 assets/ 的相对目录结构。部署到 GitHub Pages 时，将 index.html 和 assets/ 一起放在仓库发布根目录。

此包只在本地生成，尚未上传或提交。
